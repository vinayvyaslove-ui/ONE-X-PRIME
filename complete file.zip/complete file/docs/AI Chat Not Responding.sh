Solution:
1. Check API key in settings
2. Verify internet connection
3. Try refreshing page
4. Use simpler queries initially