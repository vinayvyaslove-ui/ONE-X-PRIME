Solution:
1. Check internet connection
2. Verify GST portal credentials
3. Try sandbox mode first
4. Contact support if persistent