Settings → Automation → Enable:
- Auto-calculate returns
- Auto-file on deadline day
- Auto-payment (optional)