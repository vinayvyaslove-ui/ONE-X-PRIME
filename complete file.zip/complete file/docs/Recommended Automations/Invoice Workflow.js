Settings → Invoices → Enable:
- Auto-number invoices
- Auto-send to customers
- Auto-archive after payment