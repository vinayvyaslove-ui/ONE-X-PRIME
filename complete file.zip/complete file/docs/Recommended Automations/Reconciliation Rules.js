Settings → Reconciliation → Set:
- Auto-run weekly
- Alert on >5% mismatch
- Auto-match similar invoices