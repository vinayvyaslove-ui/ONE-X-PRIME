Instead of searching menus, ask AI:
"File GSTR-3B for last month"
"Show unpaid invoices"
"Predict next month's tax"