Weekly: Review dashboard
Monthly: Check compliance score
Quarterly: Audit automation rules