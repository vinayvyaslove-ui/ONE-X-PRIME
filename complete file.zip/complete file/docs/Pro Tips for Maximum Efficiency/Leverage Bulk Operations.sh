For repetitive tasks:
- Bulk invoice generation
- Bulk GSTIN validation
- Bulk document upload