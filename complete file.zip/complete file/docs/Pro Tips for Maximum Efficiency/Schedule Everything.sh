Don't remember deadlines:
Settings → Automation → Schedule:
- Weekly reconciliation
- Monthly filing
- Daily backup