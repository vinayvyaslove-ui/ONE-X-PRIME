# Type in the chat box:
"Help me file GSTR-1 for March"
"What's my tax liability this month?"
"Generate invoice for ABC Corp"