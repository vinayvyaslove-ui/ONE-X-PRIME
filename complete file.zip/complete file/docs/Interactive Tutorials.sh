Access: Dashboard → Help → Interactive Tutorials

Available Tutorials:
1. "Create and Send Invoice"
2. "File GSTR-1 Return"
3. "Reconcile Transactions"
4. "Set Up Automations"