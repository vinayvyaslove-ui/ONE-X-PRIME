Solution:
1. Check customer GSTIN format
2. Verify tax rates are configured
3. Clear browser cache
4. Try different template