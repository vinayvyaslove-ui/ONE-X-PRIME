# Integration Guide
- Accounting software integration
- Payment gateway setup
- ERP system connectors
- Custom workflow automation