Solution:
1. Clear browser cache
2. Use latest Chrome/Firefox
3. Check internet speed
4. Disable browser extensions