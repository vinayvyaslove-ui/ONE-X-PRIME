Access the application:
Open browser and navigate to http://localhost:3000

Key Features Implemented:
Voice Command Processing: Complete voice recognition system

GST Calculation: Automatic GST calculation with multiple rates

Multi-language Support: 5+ Indian languages

Invoice Management: Create, view, and manage invoices

Expense Tracking: Record and categorize expenses

Financial Reports: Generate various financial reports

User Authentication: Secure login and registration

Real-time Updates: Socket.io for live updates

Document OCR: Extract text from uploaded documents

Responsive Design: Mobile-friendly interface