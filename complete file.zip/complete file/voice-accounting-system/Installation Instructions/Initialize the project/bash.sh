npm init -y
npm install express mongoose multer cors dotenv bcryptjs jsonwebtoken socket.io tesseract.js node-fetch pdf-parse csv-parser xlsx
npm install -D nodemon jest