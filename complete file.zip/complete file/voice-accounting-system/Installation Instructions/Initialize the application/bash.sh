npm run setup
npm start