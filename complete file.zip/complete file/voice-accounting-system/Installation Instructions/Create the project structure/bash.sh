mkdir voice-accounting-system
cd voice-accounting-system