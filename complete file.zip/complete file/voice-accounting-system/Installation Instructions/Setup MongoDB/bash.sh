# Install MongoDB if not installed
# Start MongoDB service
mongod --dbpath ./data/db