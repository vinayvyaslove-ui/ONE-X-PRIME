cp .env.example .env
# Edit .env with your configuration