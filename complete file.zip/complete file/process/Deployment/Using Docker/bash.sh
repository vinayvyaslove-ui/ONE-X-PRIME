docker build -t voice-accounting .
docker run -p 3000:3000 voice-accounting